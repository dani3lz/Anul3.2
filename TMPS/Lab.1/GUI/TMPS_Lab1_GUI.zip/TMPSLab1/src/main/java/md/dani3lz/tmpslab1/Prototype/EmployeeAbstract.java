package md.dani3lz.tmpslab1.Prototype;

public abstract class EmployeeAbstract {
    public abstract EmployeeAbstract copy();
}
