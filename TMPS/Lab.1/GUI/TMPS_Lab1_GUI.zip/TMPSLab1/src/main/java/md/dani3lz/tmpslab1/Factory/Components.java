package md.dani3lz.tmpslab1.Factory;

public interface Components {
    public int price();
    public String model();
    public int year();
    public double ranking();
    public String corporation();
}
